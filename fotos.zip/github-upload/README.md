# Portifólio — Alan Aquino

Site de portfólio pessoal. Analista de Negócios na Universidade Ceuma (Oxygeni HUB) e desenvolvedor full stack em formação — dados, IA e desenvolvimento web.

**Site no ar:** https://aaquino0.github.io/Portifolio_/

![Home do portfólio](screenshots/01-home.png)

---

## Sobre

Sou Analista de Negócios na Central de Matrícula da Universidade Ceuma, dentro do Oxygeni HUB — agência de inovação do Grupo Ceuma, em São Luís (MA). Trabalho com matrícula e rematrícula, validação documental e planos de pagamento, dou suporte técnico ao TOTVS RM Educacional e ao Rubeus, e uso SQL Server (SSMS) para extrair e analisar dados acadêmicos e financeiros.

Em paralelo, curso duas graduações — CST em Análise e Desenvolvimento de Sistemas (Universidade Ceuma) e Engenharia da Computação (UFMA) — e venho construindo uma base técnica em Python, análise de dados, Power BI, visão computacional, automação com IA e desenvolvimento full stack.

Mais de 46 certificações concluídas em cerca de um ano.

---

## O que o site tem

| Seção | Conteúdo |
| --- | --- |
| Home | Destaques, competências, trilho de certificações e reconhecimentos |
| Projetos | Estudos de caso com contexto, decisões e resultado |
| Certificados | 10 certificações em destaque + histórico completo no LinkedIn |
| Sobre | Experiência, formação e detalhamento do cargo atual |
| Contato | E-mail, LinkedIn, GitHub e localização |

---

## Projetos em destaque

- **EDX Capital — plataforma full stack, automação e comunicação.** Plataforma de gestão de ativos de energia construída nas duas pontas (interface, lógica de negócio, modelagem de dados e integrações), automação de dimensionamento de BESS via n8n, e vídeo institucional com persona de agronegócio.
- **Análise de dados acadêmicos e financeiros (Universidade Ceuma).** Consultas em SQL Server cruzando dados de TOTVS RM e Rubeus como base de decisão da Central de Matrícula.
- **Suporte técnico a TOTVS RM Educacional e Rubeus.** Ponte entre a operação de matrícula e a área de tecnologia.
- **Artigo científico: NLP aplicado ao agronegócio.** Pesquisa em formato ABNT.

---

## Telas

**Projetos** — índice em lista com cliente, ano, resumo e tecnologias; cada linha abre um estudo de caso.

![Projetos](screenshots/02-projetos.png)
![Projetos — continuação](screenshots/03-projetos-2.png)

**Certificados** — as dez mais relevantes em destaque, com link para o histórico completo no LinkedIn.

![Certificados](screenshots/04-certificados.png)

**Sobre** — o cargo detalhado em seis frentes e as habilidades técnicas agrupadas por natureza.

![Sobre — o cargo no dia a dia](screenshots/05-sobre-cargo.png)
![Sobre — habilidades técnicas](screenshots/06-sobre-habilidades.png)

**Reconhecimentos** — seis marcos, do hackathon INAED à palestra com físicos da Penn State.

![Reconhecimentos e marcos](screenshots/07-reconhecimentos.png)

**Bilíngue e com dois temas** — português e inglês, claro e escuro. Atalhos: `T` troca o tema, `L` troca o idioma.

![Versão em inglês](screenshots/08-home-en.png)
![Tema claro](screenshots/09-tema-claro.png)

---

## Stack

`HTML` · `CSS` · `JavaScript` · `SQL Server` · `Python` · `Power BI` · `n8n` · `Figma`

---

## Rodando localmente

O site é um arquivo único e autocontido — sem build, sem dependências, sem servidor:

```bash
git clone https://github.com/Aaquino0/Portifolio_.git
cd Portifolio_
# abra index.html no navegador
```

Inclui tema claro/escuro, versões em português e inglês, navegação por rotas e microinterações. Atalhos: `T` alterna o tema, `L` alterna o idioma.

---

## Contato

- **E-mail:** alanaquinonina@gmail.com
- **LinkedIn:** https://www.linkedin.com/in/alan-aquino-b994b4189
- **GitHub:** https://github.com/Aaquino0
- **Localização:** São Luís, Maranhão, Brasil
